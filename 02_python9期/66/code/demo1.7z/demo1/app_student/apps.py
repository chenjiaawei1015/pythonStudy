from django.apps import AppConfig


class AppStudentConfig(AppConfig):
    name = 'app_student'
