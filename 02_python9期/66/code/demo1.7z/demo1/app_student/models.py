from django.db import models
from app_classes.models import Classes


# Create your models here.

class Student(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    cid = models.ForeignKey(to=Classes, to_field='id', on_delete=models.CASCADE)
