from django.urls import re_path
from . import views

urlpatterns = [
    re_path(r'list/', views.StudentList.as_view(), name='list'),
    re_path(r'add_student/', views.AddStudent.as_view(), name='add_student'),
    re_path(r'edit_student/(?P<student_id>\d+)', views.EditStudent.as_view(), name='edit_student'),
    re_path(r'delete_student/(?P<student_id>\d+)', views.DeleteStudent.as_view(), name='delete_student'),
]
