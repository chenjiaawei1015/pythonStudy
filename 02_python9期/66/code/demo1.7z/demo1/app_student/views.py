from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import reverse
from django.views import View
from . import models as models_student
from app_classes import models as models_classes


# Create your views here.

class StudentList(View):
    def get(self, request):
        query_student_list = models_student.Student.objects.all()
        return render(request, 'app_student/student_list.html', {'student_list': query_student_list})

    def post(self, request):
        pass


class AddStudent(View):
    def get(self, request):
        query_classes_list = models_classes.Classes.objects.all()
        return render(request, "app_student/add_student.html", {'class_list': query_classes_list})

    def post(self, request):
        student_name = request.POST.get('student_name')
        class_id = request.POST.get('class_id')

        choose_class = models_classes.Classes.objects.get(id=class_id)
        models_student.Student.objects.create(name=student_name, cid=choose_class)

        url = reverse('student:list')
        return redirect(url)


class EditStudent(View):
    def get(self, request, student_id):
        edit_student_obj = models_student.Student.objects.get(id=student_id)
        query_classes_list = models_classes.Classes.objects.all()
        return render(request, 'app_student/edit_student.html',
                      {'student': edit_student_obj, 'class_list': query_classes_list})

    def post(self, request, student_id):
        edit_student_obj = models_student.Student.objects.get(id=student_id)
        edit_student_obj.name = request.POST.get('student_name')

        choose_class_id = request.POST.get('class_id')
        choose_class = models_classes.Classes.objects.get(id=choose_class_id)
        edit_student_obj.cid = choose_class
        edit_student_obj.save()

        url = reverse('student:list')
        return redirect(url)


class DeleteStudent(View):
    def get(self, request, student_id):
        delete_student_obj = models_student.Student.objects.get(id=student_id)
        delete_student_obj.delete()

        url = reverse('student:list')
        return redirect(url)
