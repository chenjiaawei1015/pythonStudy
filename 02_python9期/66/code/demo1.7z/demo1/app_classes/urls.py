from django.urls import re_path
from . import views

urlpatterns = [
    re_path(r'list/', views.ClassesList.as_view(), name='list'),
    re_path(r'add_classes/', views.AddClass.as_view(), name='add_classes'),
    re_path(r'edit_classes/(?P<class_id>\d+)', views.EditClasses.as_view(), name='edit_classes'),
    re_path(r'delete_classes/(?P<class_id>\d+)', views.DeleteClasses.as_view(), name='delete_classes'),
]
