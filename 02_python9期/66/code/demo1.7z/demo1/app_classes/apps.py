from django.apps import AppConfig


class AppClassesConfig(AppConfig):
    name = 'app_classes'
