from django.shortcuts import render
from django.views import View
from django.shortcuts import redirect
from django.shortcuts import reverse
from . import models


# Create your views here.

class ClassesList(View):

    def get(self, request):
        query_classes_list = models.Classes.objects.all()
        return render(request, "app_classes/classes_list.html", {"class_list": query_classes_list})

    def post(self, request):
        pass


class AddClass(View):
    def get(self, request):
        return render(request, 'app_classes/add_classes.html')

    def post(self, request):
        new_class_name = request.POST.get('class_name')
        models.Classes.objects.create(name=new_class_name)

        url = reverse('classes:list')
        return redirect(url)


class EditClasses(View):
    def get(self, request, class_id):
        edit_class_obj = models.Classes.objects.get(id=class_id)
        return render(request, 'app_classes/edit_classes.html', {'edit_classes': edit_class_obj})

    def post(self, request, class_id):
        edit_class_obj = models.Classes.objects.get(id=class_id)
        edit_class_obj.name = request.POST.get('class_name')
        edit_class_obj.save()

        url = reverse('classes:list')
        return redirect(url)


class DeleteClasses(View):
    def get(self, request, class_id):
        delete_class_obj = models.Classes.objects.get(id=class_id)
        delete_class_obj.delete()

        url = reverse('classes:list')
        return redirect(url)

    def post(self, request, class_id):
        pass
