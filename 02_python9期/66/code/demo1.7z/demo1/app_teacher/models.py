from django.db import models
from app_classes.models import Classes


# Create your models here.

class Teacher(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    cid = models.ManyToManyField(to=Classes)
