from django.urls import re_path
from . import views

urlpatterns = [
    re_path(r'list/', views.TeacherList.as_view(), name='list'),
    re_path(r'add_teacher/', views.AddTeacher.as_view(), name='add_teacher'),
    re_path(r'edit_teacher/(?P<teacher_id>\d+)', views.EditTeacher.as_view(), name='edit_teacher'),
    re_path(r'delete_teacher/(?P<teacher_id>\d+)', views.DeleteTeacher.as_view(), name='delete_teacher'),
]
