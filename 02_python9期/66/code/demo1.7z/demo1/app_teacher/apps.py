from django.apps import AppConfig


class AppTeacherConfig(AppConfig):
    name = 'app_teacher'
