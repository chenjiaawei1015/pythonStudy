from django.shortcuts import render
from django.shortcuts import reverse
from django.shortcuts import redirect
from django.views import View
from . import models as model_teacher
from app_classes import models as model_classes


# Create your views here.

class TeacherList(View):
    def get(self, request):
        query_teacher_list = model_teacher.Teacher.objects.all()
        return render(request, 'app_teacher/teacher_list.html', {'teacher_list': query_teacher_list})

    def post(self, request):
        pass


class AddTeacher(View):
    def get(self, request):
        query_classes_list = model_classes.Classes.objects.all()
        return render(request, 'app_teacher/add_teacher.html', {'class_list': query_classes_list})

    def post(self, request):
        teacher_name = request.POST.get('teacher_name')
        class_id_list = request.POST.getlist('class_ids')
        new_teacher = model_teacher.Teacher.objects.create(name=teacher_name)
        new_teacher.cid.set(class_id_list)
        new_teacher.save()

        url = reverse('teacher:list')
        return redirect(url)


class EditTeacher(View):
    def get(self, request, teacher_id):
        edit_teacher_obj = model_teacher.Teacher.objects.get(id=teacher_id)
        query_classes_list = model_classes.Classes.objects.all()
        return render(request, 'app_teacher/edit_teacher.html',
                      {'teacher': edit_teacher_obj, 'class_list': query_classes_list})

    def post(self, request, teacher_id):
        edit_teacher_obj = model_teacher.Teacher.objects.get(id=teacher_id)
        edit_teacher_obj.name = request.POST.get('teacher_name')

        choose_classes_id_list = request.POST.getlist('class_ids')
        edit_teacher_obj.cid.set(choose_classes_id_list)

        edit_teacher_obj.save()

        url = reverse('teacher:list')
        return redirect(url)


class DeleteTeacher(View):
    def get(self, request, teacher_id):
        delete_teacher_obj = model_teacher.Teacher.objects.get(id=teacher_id)
        delete_teacher_obj.delete()
        url = reverse('teacher:list')
        return redirect(url)

    def post(self, request, teacher_id):
        pass
