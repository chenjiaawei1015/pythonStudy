from django.shortcuts import render
from django.shortcuts import redirect
from app01 import models

URL_CLASS_LIST = "/class_list/"
URL_STUDENT_LIST = "/student_list/"
URL_TEACHER_LIST = "/teacher_list/"


# Create your views here.

def home(request):
    """
    首页
    :param request:
    :return:
    """
    return render(request, "home.html")


def class_list(request):
    """
    班级管理
    :param request:
    :return:
    """
    classes_list = models.Classes.objects.all()
    return render(request, "class_list.html", {"classes_list": classes_list})


def add_classes(request):
    """
    班级添加页面
    :param request:
    :return:
    """
    if is_post_request(request):
        new_name = request.POST.get("class_name")
        models.Classes.objects.create(name=new_name)
        return redirect(URL_CLASS_LIST)
    else:
        return render(request, "add_classes.html")


def delete_class(request):
    """
    删除班级
    :param request:
    :return:
    """
    delete_id = request.GET.get('id')
    delete_class_obj = models.Classes.objects.get(id=delete_id)
    delete_class_obj.delete()
    return redirect(URL_CLASS_LIST)


def edit_class(request):
    """
    编辑班级
    :param request:
    :return:
    """
    if is_post_request(request):
        edit_id = request.POST.get('id')
        edit_class_obj = models.Classes.objects.get(id=edit_id)
        edit_class_obj.name = request.POST.get('name')
        edit_class_obj.save()
        return redirect(URL_CLASS_LIST)
    else:
        edit_id = request.GET.get('id')
        edit_class_obj = models.Classes.objects.get(id=edit_id)
        return render(request, "edit_class.html", {"edit_obj": edit_class_obj})


def student_list(request):
    """
    学生列表页面
    :param request:
    :return:
    """
    student_list_obj = models.Student.objects.all()
    return render(request, "student_list.html", {"student_list": student_list_obj})


def add_student(request):
    """
    添加学生
    :param request:
    :return:
    """
    if is_post_request(request):
        student_name = request.POST.get('name')
        class_id = request.POST.get('class')
        models.Student.objects.create(name=student_name, cid_id=class_id)
        return redirect(URL_STUDENT_LIST)
    else:
        query_classes_list = models.Classes.objects.all()
        return render(request, "add_student.html", {"class_list": query_classes_list})


def delete_student(request):
    """
    删除学生
    :param request:
    :return:
    """
    delete_id = request.GET.get('id')
    delete_student_obj = models.Student.objects.get(id=delete_id)
    delete_student_obj.delete()
    return redirect(URL_STUDENT_LIST)


def edit_student(request):
    """
    编辑学生
    :param request:
    :return:
    """
    if is_post_request(request):
        edit_id = request.POST.get("id")
        edit_student_obj = models.Student.objects.get(id=edit_id)
        edit_student_obj.name = request.POST.get("name")
        edit_student_obj.cid_id = request.POST.get('class')
        edit_student_obj.save()
        return redirect(URL_STUDENT_LIST)
    else:
        edit_id = request.GET.get('id')
        edit_student_obj = models.Student.objects.get(id=edit_id)
        query_class_list = models.Classes.objects.all()
        return render(request, "edit_student.html", {"student": edit_student_obj, "class_list": query_class_list})


def teacher_list(request):
    """
    老师列表
    :param request:
    :return:
    """
    query_teacher_list = models.Teacher.objects.all()
    return render(request, "teacher_list.html", {"teacher_list": query_teacher_list})


def add_teacher(request):
    """
    添加老师
    :param request:
    :return:
    """
    if is_post_request(request):
        teacher_name = request.POST.get('name')

        # 获取一组值的时候, 需要使用 getlist 方法
        class_id_list = request.POST.getlist('class_list')
        new_teacher = models.Teacher.objects.create(name=teacher_name)
        # 设置当前老师授课的班级
        new_teacher.cid.set(class_id_list)
        new_teacher.save()
        return redirect(URL_TEACHER_LIST)
    else:
        query_class_list = models.Classes.objects.all()
        return render(request, "add_teacher.html", {"class_list": query_class_list})


def delete_teacher(request):
    """
    删除老师
    :param request:
    :return:
    """
    delete_id = request.GET.get('id')
    query_teacher = models.Teacher.objects.get(id=delete_id)
    query_teacher.delete()
    return redirect(URL_TEACHER_LIST)


def edit_teacher(request):
    """
    编辑老师
    :param request:
    :return:
    """
    if is_post_request(request):
        edit_id = request.POST.get('id')
        teacher_obj = models.Teacher.objects.get(id=edit_id)
        teacher_obj.name = request.POST.get('name')

        class_id_list = request.POST.getlist('class_list')
        teacher_obj.cid.set(class_id_list)
        teacher_obj.save()
        return redirect(URL_TEACHER_LIST)
    else:
        edit_teacher_id = request.GET.get('id')
        teacher_obj = models.Teacher.objects.get(id=edit_teacher_id)
        query_class_list = models.Classes.objects.all()
        return render(request, "edit_teacher.html", {"teacher": teacher_obj, "class_list": query_class_list})


def is_post_request(request):
    return request.method.lower() == 'post'
