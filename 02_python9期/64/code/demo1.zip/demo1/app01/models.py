from django.db import models


# Create your models here.

class Classes(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, default='默认班级')


class Student(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, default='')
    cid = models.ForeignKey(to='Classes', to_field='id', on_delete=models.CASCADE)


class Teacher(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, default='')
    # 多对多的关系
    cid = models.ManyToManyField(to='Classes')
