from django.shortcuts import render
from django.shortcuts import HttpResponse
from django.shortcuts import redirect
from app01 import models


# Create your views here.

def get_test(request):
    print(request.GET)
    # http://127.0.0.1:8000/getTest
    # <QueryDict: {}>

    # http://127.0.0.1:8000/getTest?id=1&password=123
    # <QueryDict: {'id': ['1'], 'password': ['123']}>
    return HttpResponse("服务端接收到 GET 请求")


def post_test(request):
    print(request.POST)
    return HttpResponse("服务端接收到 POST 请求")


def redirect_test(request):
    return redirect("http://www.qq.com")


def login(request):
    if request.method.upper() == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        print(f'用户名 {username} , 密码 {password}')
        if username == "a" and password == "1":
            return HttpResponse("登录成功")
        else:
            return HttpResponse("登录失败")
    else:
        print(f'请求方式 {request.method}')
        return render(request, "login.html")


def check_user3(username, password):
    try:
        # 查询指定用户, 如果查询不到, 则会发生异常
        ret = models.User.objects.get(user_name=username, password=password)
        print(f'check_user3 查询的数据 : username:{ret.user_name}, password:{ret.password}')
        return True
    except Exception as ex:
        print("查询发生了异常")
        return False


def check_user2(username, password):
    # 查询指定用户
    # 返回的是一个列表, 如果数据不存在, 也是一个空列表
    ret = models.User.objects.filter(user_name=username, password=password)
    if ret:
        for index, value in enumerate(ret):
            print(f'check_user2 查询的第 {index+1} 条数据, username:{value.user_name}, password:{value.password}')

        return True
    else:
        return False


def check_user1(username, password):
    # 查询所有用户
    # 导入 molel 模块, 通过类名.objects.all() 可以查询所有数据
    ret = models.User.objects.all()

    for item_user in ret:
        if item_user.user_name == username and item_user.password == password:
            return True
    return False


def login2(request):
    if request.method.upper() == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        # 根据用户名和密码查询数据库
        res1 = check_user1(username, password)
        print(f'check_user1 查询结果 {res1}')
        res2 = check_user2(username, password)
        print(f'check_user2 查询结果 {res2}')
        res3 = check_user3(username, password)
        print(f'check_user2 查询结果 {res3}')
    return render(request, "login2.html")


def login3(request):
    data = {}
    if request.method.upper() == "POST":
        data = {"error_username": "用户名错误", "error_password": "密码错误", "error_msg": "登录失败"}
    return render(request, "login2.html", data)
