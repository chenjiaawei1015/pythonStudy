from django.db import models


# Create your models here.

# 定义表名, 实际的表名为app_类名
# 例如类名为 User , 当前 app 的名称为 app01 , 则实际的表名为 app01_user
# 必须继承 models.Model
class User(models.Model):
    # 定义表结构
    # int 类型, 主键
    id = models.IntegerField(primary_key=True)
    # varchar 类型, 长度最大为20
    user_name = models.CharField(max_length=20)
    password = models.CharField(max_length=20)

